export const udata = {
  data: { base: "BTC", currency: "USD", amount: "25068.99" },
};
